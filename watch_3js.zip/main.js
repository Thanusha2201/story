import './style.css';
import * as THREE from 'three';
import gsap from 'gsap';
/* import TWEEN from '@tweenjs/tween.js' */
import * as TWEEN from "three/addons/libs/tween.module.js";
import {
    OrbitControls
} from 'three/examples/jsm/controls/OrbitControls.js';
import {
    GLTFLoader
} from 'three/addons/loaders/GLTFLoader.js';
import {
    RGBELoader
} from 'three/examples/jsm/loaders/RGBELoader.js';
import {
    DRACOLoader
} from 'three/addons/loaders/DRACOLoader'
import {
    CSS2DRenderer,
    CSS2DObject
} from 'three/examples/jsm/renderers/CSS2DRenderer.js';

import {
    label
} from 'three/webgpu';
/* import { texture } from 'three/webgpu';
import { ThreeMFLoader } from 'three/examples/jsm/Addons.js'; */

const renderer = new THREE.WebGLRenderer({
    antialias: true
});
if (window.innerWidth <= 1536) {
    renderer.setSize(window.innerWidth, window.innerHeight);
} else {
    renderer.setSize(1536, 950);
}

document.getElementById('inner-canvas').appendChild(renderer.domElement);

// Sets the color of the background.
/* renderer.setClearColor(0xFEFEFE); */
const scene = new THREE.Scene();

let zoomClicked = false;
let dropDownOpend = false;

document.getElementById('downIcon').style.display = 'flex';
document.getElementById('upIcon').style.display = 'none';
const camera = new THREE.PerspectiveCamera(
    45,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);

renderer.setClearColor(0xFFFEEE);
// Sets orbit control to move the camera around.
const controls = new OrbitControls(camera, renderer.domElement);
controls.minDistance = 20;
controls.maxDistance = 30;
//controls.enableRotate = false;
controls.enableDamping = true;
//camera.rotation.order = 'YXZ';
controls.dampingFactor = 0.1;




// Camera positioning.
camera.position.set(0, 0, 30);
/* console.log(camera.position) */
//camera.position.set(0,6,15);
camera.lookAt(scene.position)
// Has to be done everytime we update the camera position.
controls.update();
// Creates a 12 by 12 grid helper.
/* const grid = new THREE.GridHelper(30, 30);
scene.add(grid); */

/* window.addEventListener('wheel', onMouseWheel, { passive: false }); */

window.addEventListener('mousedown', function () {
    /*  gsap.to(camera.position, {
         x:-30,
         y:-30,
         z:0,
         duration:1.5,
         onUpdate: function() {
             camera.lookAt(0,0,0)
         }
     }) */
    //console.log(pivot.rotateOnAxis())
})


/* function onMouseWheel(ev) {
    console.log(ev)
    ev.preventDefault();
} */
//Adding html elments
const labelRenderer = new CSS2DRenderer()

if (window.innerWidth <= 1536) {
    labelRenderer.setSize(window.innerWidth, window.innerHeight);
} else {
    labelRenderer.setSize(1536, 950);
}

//labelRenderer.setSize(window.innerWidth, window.innerHeight);
labelRenderer.domElement.style.position = 'absolute';
labelRenderer.domElement.style.top = '0px';
labelRenderer.domElement.style.pointerEvents = 'none';
document.body.appendChild(labelRenderer.domElement)


/* const ambientLight = new THREE.AmbientLight(0xededed, 0.8)
scene.add(ambientLight); */

/* const directionLight = new THREE.DirectionalLight(0xFFFFFF, 1)
scene.add(directionLight)
directionLight.position.set(0, 0, 0); */

// Creates an axes helper with an axis length of 4.
/* const axesHelper = new THREE.AxesHelper(4);
scene.add(axesHelper); */

const glbLoader = new GLTFLoader();
const rgbeLoader = new RGBELoader();
const dracoLoader = new DRACOLoader();

renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1;

dracoLoader.setDecoderConfig({
    type: 'js'
});
dracoLoader.setDecoderPath('https://www.gstatic.com/draco/v1/decoders/');
glbLoader.setDRACOLoader(dracoLoader);

/* 
let ringMesh;
function createPlanet(size, texture, position, ring) {
    const geo = new THREE.SphereGeometry(.2);
    const mat = new THREE.MeshStandardMaterial({
     
    });
    const mesh = new THREE.Mesh(geo, mat);
    const obj = new THREE.Object3D();
    obj.add(mesh);
    if (ring) {
      const ringGeo = new THREE.RingGeometry(
        ring.innerRadius,
        ring.outerRadius,
        32
      );
      const ringMat = new THREE.MeshBasicMaterial({
       
        side: THREE.DoubleSide
      });
      ringMesh = new THREE.Mesh(ringGeo, ringMat);
      obj.add(ringMesh);
      ringMesh.position.x = position;
      ringMesh.rotation.x =  Math.PI;
    }
    scene.add(obj);
    mesh.position.x = position;
    return { mesh, obj };
}

const saturn = createPlanet(1, "", 5, {
    innerRadius: .3,
    outerRadius: .4,
    texture: ""
  }); */


//create Hotspots
function createCpointMesh(name, x, y, z) {
    const obj = new THREE.Object3D();
    //obj.add(mesh);


    const geo = new THREE.SphereGeometry(0.15);
    const mat = new THREE.MeshBasicMaterial({
        color: 0xFFA500,

    })
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z)
    mesh.name = name;

    const material = new THREE.LineBasicMaterial({
        color: 0xFFA500,
        linewidth: 1,
        linecap: 'round', //ignored by WebGLRenderer
        linejoin: 'round' //ignored by WebGLRenderer
    });

    const ringGeo = new THREE.RingGeometry(.2, .25, 32);
    /* const ringMat = new THREE.MeshBasicMaterial({   
        color: 0xFFA500,
    }); */
    let ringMesh = new THREE.Mesh(ringGeo, material);
    mesh.add(ringMesh);

    return mesh;


}

const group = new THREE.Group();
const mesho = new THREE.Mesh();

const watchface = createCpointMesh('watchface', -1.5, -.2, 1.5)
group.add(watchface);

const crown = createCpointMesh('crown', 2.7, 0, .8)
group.add(crown);

const sidebutton = createCpointMesh('sidebutton', 2, 1, 0.7)
group.add(sidebutton);

const securebutton = createCpointMesh('securebutton', -2, 1.4, 0.7)
group.add(securebutton);

const speaker = createCpointMesh('speaker', -2.3, 0, 0.7)
group.add(speaker);

const microphone = createCpointMesh('microphone', 2, -1, 0.7)
group.add(microphone);

const sensor = createCpointMesh('sensor', 0, 0, -0.2)
group.add(sensor);


const chargingpoint = createCpointMesh('chargingpoint', 0.6, .2, -0.2)
group.add(chargingpoint);


const bands = createCpointMesh('bands', -0.1, -3.2, -1.5)
group.add(bands);


const metalpeg = createCpointMesh('metalpeg', -1, -1, 0)
group.add(metalpeg);

const claspinghole = createCpointMesh('claspinghole', 0, -.2, -5)
group.add(claspinghole);

/* const outerloop = createCpointMesh('outerloop', 0, 1.2, -5)
group.add(outerloop); */

const innerloop = createCpointMesh('innerloop', 0, -2.7, -4.3)
group.add(innerloop);


/* const sideb = createCpointMesh('bands', -0.5, 3.2, -3.5)
group.add(sideb); */

scene.add(group)


/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}


window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {
        dropDownOpend = !dropDownOpend;
        if (dropDownOpend) {
            document.getElementById('downIcon').style.display = 'flex';
            document.getElementById('upIcon').style.display = 'none';
        } else {
            document.getElementById('downIcon').style.display = 'none';
            document.getElementById('upIcon').style.display = 'flex';
        }
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}




// Tooltip creation and display when clicking sphere
const outerDiv = document.createElement('div');
outerDiv.className = 'tooltip';

/* const toolTipImage = document.createElement('div')
toolTipImage.className = 'tooltip__whitering';

outerDiv.appendChild(toolTipImage) */

const pContainer = document.createElement('div');
pContainer.appendChild(outerDiv);

const cPointLabel = new CSS2DObject(pContainer);
scene.add(cPointLabel);

const mousePos = new THREE.Vector2();
const raycaster = new THREE.Raycaster();

document.getElementById('inner-canvas').addEventListener('mousedown', function (e) {
    console.log("1111")
    //console.log(">pivotx and y..", pivot.rotation.x, pivot.rotation.y)
    /* console.log(e.clientX, e.clientY)

    console.log(this.window.innerWidth, this.window.innerHeight)
    console.log((e.clientX/this.window.innerWidth) * 2, (e.clientX/this.window.innerHeight) * 2)
    console.log((e.clientX/this.window.innerWidth) * 2 - 1, (e.clientX/this.window.innerHeight) * 2 - 1) */

    if (window.innerWidth <= 1536) {
        mousePos.x = (e.clientX / window.innerWidth) * 2 - 1;
        mousePos.y = -(e.clientY / window.innerHeight) * 2 + 1;
    } else {
        mousePos.x = (e.clientX / 1536) * 2 - 1;
        mousePos.y = -(e.clientY / 950) * 2 + 1;
    }


    /* mousePos.x = (e.clientX / window.innerWidth) * 2 - 1;
    mousePos.y = -(e.clientY / window.innerHeight) * 2 + 1; */
    raycaster.setFromCamera(mousePos, camera)

    const intersects = raycaster.intersectObject(group);
    const intersects1 = raycaster.intersectObject(mesho);
    console.log(intersects)
    console.log(intersects)


    if (intersects.length > 0) {
        console.log(intersects[0].object)
        //openToolTipWithObjectRotation(intersects[0].object.name)
        openToolTipWithCameraRotation(intersects[0].object.name);

    } else {



        outerDiv.className = "tooltip hide"


    }


    //yourVertexWorldPosition.applyMatrix4();//this transforms the new vector into world space based on the matrix you provide (line.matrixWorld)
})




let myModel;
var pivot = new THREE.Group();
//const gimbal = new THREE.Object3D();
//gimbal.add(camera);
rgbeLoader.load('./3D_all_GW3L_2024Q2_Lighting.hdr', (texture) => {
    texture.mapping = THREE.EquirectangularReflectionMapping;
    scene.environment = texture;

    //glbLoader.load('./studio_c_chuck_real_textures.glb', (gltf) => {
    glbLoader.load('./hotspot_test2 (1).glb', (gltf) => {
        const model = gltf.scene;
        //model.domElement.style.cursor = 'drag'
        //model.domElement.style.position = 'absolute';
        myModel = model;
        console.log(myModel)
        /*code for rotating from center */
        const box = new THREE.Box3().setFromObject(gltf.scene);
        box.getCenter(gltf.scene.position); // this re-sets the mesh position
        gltf.scene.position.multiplyScalar(-1);
        scene.add(pivot);
        pivot.add(gltf.scene);
        /*  scene.add(myModel); */
        myModel.add(group);
        myModel.add(cPointLabel)
        console.log("model>>>>", myModel.getObjectByName('V_band').material.color)
    },
        (progress) => {
            //console.log(progress)
        },
        (error) => {
            console.log(error)
        }
    );

},
    (inprogress) => {

    },
    (error) => {

    })

function animate(time) {
    TWEEN.update();
    controls.update();
    if (myModel) {
        //pivot.rotation.y = -time / 3000;;
        //pivot.rotation.y = 30;
        //myModel.rotation.x = - time / 3000;  //rotating in y axis
        //myModel.rotation.y = - time / 3000; 
        //myModel.rotation.y = Math.PI / 2;
        //myModel.rotation.x = -90
        //ringMesh.position.y = - time / 3000;
    }
    labelRenderer.render(scene, camera)
    renderer.render(scene, camera);
}



// usage:
//rotateObject(myPlane, 40, 30, 20);

/* labelRenderer.render(scene, camera)
    renderer.render(scene, camera); */
renderer.setAnimationLoop(animate);

window.addEventListener('resize', function () {

    if (window.innerWidth <= 1536) {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
        labelRenderer.setSize(window.innerWidth, window.innerHeight);
    } else {
        camera.aspect = 1536 / 950;
        camera.updateProjectionMatrix();
        renderer.setSize(1536, 950);
        labelRenderer.setSize(1536, 950);
    }

    /* camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    labelRenderer.setSize(window.innerWidth, window.innerHeight); */
});

// dropdown functionality
/* document.getElementById('mySelect').addEventListener('change', function() {
    var x = document.getElementById("mySelect").value;
    console.log(x)
    openToolTipWithCameraRotation(x);

}) */

document.getElementById('dropdown').addEventListener('click', function () {
    myFunction();
})



/*hotspot functionality*/
document.getElementById('watchface').addEventListener('mousedown', function (event) {
    console.log(event)
    //openToolTipWithObjectRotation('bands');
    openToolTipWithCameraRotation('watchface')
})
document.getElementById('crown').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('crown')
    //openToolTipWithObjectRotation('chargingpoint');
})
document.getElementById('sidebutton').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('sidebutton')
    //openToolTipWithObjectRotation('crown');
})
document.getElementById('securebutton').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('securebutton')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('speaker').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('speaker')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('microphone').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('microphone')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('sensor').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('sensor')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('chargingpoint').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('chargingpoint')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('bands').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('bands')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('metalpeg').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('metalpeg')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('claspinghole').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('claspinghole')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('outerloop').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('outerloop')
    //openToolTipWithObjectRotation('watchface');
})

document.getElementById('innerloop').addEventListener('mousedown', function (event) {
    console.log(event)
    openToolTipWithCameraRotation('innerloop')
    //openToolTipWithObjectRotation('watchface');
})












//bottom arrow functionality
document.getElementById('leftArrow').addEventListener('click', function () {
    cameraRotationLeft();
});
document.getElementById('rightArrow').addEventListener('click', function () {
    cameraRotationRight();
});

document.getElementById('upArrow').addEventListener('click', function () {
    cameraRotationUp();
});

document.getElementById('downArrow').addEventListener('click', function () {
    cameraRotationDown();
});

document.getElementById('zoomButton').addEventListener('click', function () {
    zoomInandOut();
});

document.getElementById('color1').addEventListener('click', function () {
    changeColor1();
});
document.getElementById('color2').addEventListener('click', function () {
    changeColor2();
});
document.getElementById('color3').addEventListener('click', function () {
    changeColor3();
});

function changeColor1() {
    document.getElementById('color1').classList.add("active");
    document.getElementById('color2').classList.remove("active");
    document.getElementById('color3').classList.remove("active");
    document.getElementById('colorText').textContent = 'Color: Hazel';

    console.log("cameraRotationDown>>>", camera.position)
    updateModelColor("color1")
}

function changeColor2() {
    document.getElementById('color1').classList.remove("active");
    document.getElementById('color2').classList.add("active");
    document.getElementById('color3').classList.remove("active");
    document.getElementById('colorText').textContent = 'Color: Obsidian';

    console.log("cameraRotationDown>>>", camera.position)
    updateModelColor('color2')
}

function changeColor3() {
    document.getElementById('color1').classList.remove("active");
    document.getElementById('color2').classList.remove("active");
    document.getElementById('color3').classList.add("active");
    document.getElementById('colorText').textContent = 'Color: Porcelain';
    console.log("cameraRotationDown>>>", camera.position)
    updateModelColor('color3')
}


function rotateModel(axis, increment) {
    camera.position.x = 0;
    camera.position.z = 1;

    console.log(camera.position);
    if (model) {
        const currentRotation = model.rotation[axis];
        const targetRotation = currentRotation + THREE.MathUtils.degToRad(increment);
        gsap.to(model.rotation, {
            [axis]: targetRotation,
            duration: 1,
            ease: "power2.inOut",
            onUpdate: () => {
                // Adjust camera to maintain the same view
                controls.update();
            }
        });
    }
}


function openToolTipWithObjectRotation(item) {
    console.log("openToolTipWithObjectRotation", item);
    //pivot.rotation.y = Math.PI; 
    switch (item) {
        case "watchface":


            break;
        case "chargingpoint":

            break;

        case "crown":
            console.log(pivot.rotation.x)
            console.log(pivot.rotation.y)
            /* pivot.rotation.y = -(Math.PI / 2)
            pivot.rotation.x = 0; */
            cPointLabel.position.set(2.7, 0, .8);
            outerDiv.textContent = 'Crown';
            outerDiv.className = 'tooltip show';
            gsap.to(pivot.rotation, {
                duration: 1,
                y: -(Math.PI / 2),
                x: 0,
                // arrow functions are handy for concise callbacks
                onComplete: () => {
                    camera.lookAt(0, 0, 0)
                    controls.update();
                }
            });

            break;

        case "bands":

            break;

        default:
            break;
    }
}

function openToolTipWithCameraRotation(item) {
    switch (item) {
        case "watchface":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(-1.5, -.2, 1.5);
            outerDiv.textContent = 'Watch Face';
            gsap.to(camera.position, {
                x: 0,
                y: 0,
                z: 30,
                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0);
                    controls.update()
                }
            })

            break;

        case "crown":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(2.7, 0, .8);
            outerDiv.textContent = 'Crown';
            //rotateObject(myModel, 0, -90, 0)
            gsap.to(camera.position, {
                x: 30,
                y: 0,
                z: 0,
                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })

            break;

        case "sidebutton":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(2, 1, 0.7);
            outerDiv.textContent = 'Side button';
            //rotateObject(myModel, 0, -90, 0)
            gsap.to(camera.position, {
                x: 30,
                y: 0,
                z: 0,
                duration: .5,

                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })

            break;

        case "securebutton":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(-2, 1.4, 0.7);
            outerDiv.textContent = 'Secure button';
            //rotateObject(myModel, 0, -90, 0)
            gsap.to(camera.position, {
                x: -30,
                y: 0,
                z: 0,
                duration: .5,

                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })

            break;

        case "speaker":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(-2.3, 0, 0.7);
            outerDiv.textContent = 'Speaker';
            //rotateObject(myModel, 0, -90, 0)
            gsap.to(camera.position, {
                x: -30,
                y: 0,
                z: 0,
                duration: .5,

                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })

            break;

        case "microphone":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(2, -1, 0.7);
            outerDiv.textContent = 'Microphone';
            //rotateObject(myModel, 0, -90, 0)
            gsap.to(camera.position, {
                x: 30,
                y: 0,
                z: 0,
                duration: .5,

                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })

            break;


        case "sensor":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(0, 0, -0.2);
            outerDiv.textContent = 'Sensor'
            gsap.to(camera.position, {
                x: 20,
                y: 0,
                z: -30,
                duration: .5,

                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;


        case "chargingpoint":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(0.6, .2, -0.2);
            outerDiv.textContent = 'Charging Point'
            gsap.to(camera.position, {
                x: 20,
                y: 0,
                z: -30,
                duration: .5,

                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;



        case "bands":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(-0.1, -3.2, -1.5);
            outerDiv.textContent = 'Bands'
            gsap.to(camera.position, {
                x: 30,
                y: 20,
                z: -0,
                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;

        case "metalpeg":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(-1, -1, 0);
            outerDiv.textContent = 'Metal peg'
            gsap.to(camera.position, {
                x: -10,
                y: 0,
                z: -25,

                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;

        case "claspinghole":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(0, -.2, -5);
            outerDiv.textContent = 'Clasping hole'
            gsap.to(camera.position, {
                x: 0,
                y: 0,
                z: -30,
                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;

        case "outerloop":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(0, 1.2, -5);
            outerDiv.textContent = 'Outer loop'
            gsap.to(camera.position, {
                x: 0,
                y: 0,
                z: -30,

                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;

        case "innerloop":
            outerDiv.className = 'tooltip show';
            cPointLabel.position.set(0, -2.7, -4.3);
            outerDiv.textContent = 'Inner loop'
            gsap.to(camera.position, {
                x: 0,
                y: 5,
                z: -30,

                duration: .5,
                onUpdate: function () {
                    camera.lookAt(0, 0, 0)
                    controls.update()
                }
            })
            break;


        default:
            break;
    }
}


function updateModelColor(color) {
    /*color change code */
    /*   console.log("model>>>>", myModel)
      console.log("model>>>>", myModel.getObjectByName('V_band'))
      console.log("model>>>>", myModel.getObjectByName('V_band').material.color)
      console.log("model>>>>", myModel.getObjectByName("V_screen"))
      console.log("model>>>>", myModel.getObjectByName("V_enclosureButton"))
      console.log("model>>>>", myModel.getObjectByName("V_crown")) */
    myModel.traverse(function (child) {
        if (child.name == 'V_band' || child.name == 'V_screen' || child.name == 'V_enclosureButton' || child.name == 'V_crown' || child.name == 'V_band001' || child.name == 'V_crown001' || child.name == 'V_enclosureButton001' || child.name == 'V_screen001' || child.name == 'V_band002' || child.name == 'V_crown002' || child.name == 'V_enclosureButton002' || child.name == 'V_screen002') {
            child.visible = false;
        }
        if (color == 'color1') {
            if (child.name == 'V_band002' || child.name == 'V_crown002' || child.name == 'V_enclosureButton002' || child.name == 'V_screen002') {
                child.visible = true;
            }
        }
        if (color == 'color2') {
            if (child.name == 'V_band001' || child.name == 'V_crown001' || child.name == 'V_enclosureButton001' || child.name == 'V_screen001') {
                child.visible = true;
            }
        }
        if (color == 'color3') {
            if (child.name == 'V_band' || child.name == 'V_crown' || child.name == 'V_enclosureButton' || child.name == 'V_screen') {
                child.visible = true;
            }
        }
    });

}


function cameraRotationLeft() {
    camera.lookAt(0, 0, 0);
    console.log("camera.rotation.x>>>", camera.rotation.x);
    console.log("camera.rotation.y>>>", camera.rotation.y);

    let cameraAngleX = THREE.MathUtils.radToDeg(camera.rotation.x).toFixed(2);
    let cameraAngleY = THREE.MathUtils.radToDeg(camera.rotation.y).toFixed(2);

    console.log("cameraAngleY in deg>>>", cameraAngleY);
    console.log("cameraAngleX in deg", cameraAngleX);


    console.log("camera.rotation.y>>>", camera.rotation.y.toFixed(2));
    console.log("camera.rotation.x>>>>", camera.rotation.x.toFixed(2));

    const heading1 = camera.rotation.y;
    const heading2 = camera.rotation.x;
    /*  const radians1 = camera.rotation.y;
     const radians2 = camera.rotation.x; */
    const radians1 = camera.rotation.y > 0 ? camera.rotation.y : (2 * Math.PI) + camera.rotation.y;
    const radians2 = camera.rotation.x > 0 ? camera.rotation.x : (2 * Math.PI) + camera.rotation.x;
    const degreesy = THREE.MathUtils.radToDeg(radians1);
    const degreesx = THREE.MathUtils.radToDeg(radians2);

    console.log("degreesy", degreesy.toFixed(2));
    console.log("degreesx", degreesx.toFixed(2));
    console.log("========================");

}
function cameraRotationUp() {
}
function cameraRotationRight() {
}
function cameraRotationDown() {
}
function zoomInandOut() {
    console.log("zoomInandOut>>>", camera.position)
    zoomClicked = !zoomClicked;
    if (zoomClicked) {
        tweenzoom(true);
    } else {
        tweenzoom(false);
    }
}


function tweenzoom(inout) { // in - true, out - false

    let desiredDistance = inout ? controls.minDistance : controls.maxDistance;

    let dir = new THREE.Vector3();
    camera.getWorldDirection(dir);
    dir.negate();
    let dist = controls.getDistance();

    new TWEEN.Tween({ val: dist })
        .to({ val: desiredDistance }, 1000)
        .onUpdate(val => {
            camera.position.copy(controls.target).addScaledVector(dir, val.val);
        })
        .start();
}


controls.addEventListener('end', () => {
    //console.log('END', myModel.rotation, myModel.rotation)
    console.log('END', pivot.rotation)
    console.log('END', camera.rotation)
    /*    pivot.rotation.x = 3.14;
       pivot.rotation.y = 3.14; */

})

controls.addEventListener('change', () => {
    /*  var neededPVMmatrix = new THREE.Matrix4().multiplyMatrices(pivot.matrixWorld, camera.matrixWorld);
     console.log(neededPVMmatrix)
     var euler = new THREE.Euler().setFromRotationMatrix(neededPVMmatrix);
     var y = THREE.MathUtils.radToDeg(euler._y);
     var x = THREE.MathUtils.radToDeg(euler._x);
     var z = THREE.MathUtils.radToDeg(euler._z);
     //var y = THREE.MathUtils.radToDeg(euler._y);
 
     neededPVMmatrix.multiplyMatrices(neededPVMmatrix, camera.projectionMatrix);
     console.log("XXX>>>>", x)
     console.log("YYY>>>>", y)
     //console.log("ZZZZ>>>>",z)
 
     console.log("camera.rotation.y>>>", camera.rotation.y.toFixed(2));
     console.log("camera.rotation.x>>>>", camera.rotation.x.toFixed(2));
     //console.log("pivot.rotation.x>>>>", pivot.rotation.x.toFixed(2));
     //console.log("pivot.rotation.y>>>>", pivot.rotation.y.toFixed(2));
 
     const heading1 = camera.rotation.y;
     const heading2 = camera.rotation.x;
     const radians1 = heading1 > 0 ? heading1 : (2 * Math.PI) + heading1;
     const radians2 = heading2 > 0 ? heading2 : (2 * Math.PI) + heading2;
     const degreesy = THREE.MathUtils.radToDeg(radians1);
     const degreesx = THREE.MathUtils.radToDeg(radians2);
 
     console.log("camera.rotation.y", degreesy.toFixed(2));
     console.log("camera.rotation.x", degreesx.toFixed(2));
     console.log("========================");
     console.log(camera.rotation.x) */

    pivot.rotation.x = 0
    pivot.rotation.y = 0
})